import React from "react";
import { Box, Typography, Stack, Grid } from "@mui/material";
// Importing the background image as a string assuming it's a file path
import backgroundImage from "/public/Images/topfooter/footer-logo.png";
import { Button } from "@mui/material";
import { Block, BorderBottom, BorderTop } from "@mui/icons-material";
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import MailOutlineIcon from '@mui/icons-material/MailOutline';

const FirstBottom = () => {
  return (
    <>
      <Box sx={{
        backgroundImage: "url( '/public/Images/topfooter/footer-bg-one.jpg')",
        width: "100vw",
        hight: "80v",
        display: "flex",
        justifyContent: "center",

      }} >

        <Box sx={{
          paddingTop: { xl: "50px" },
          paddingBottom: { xl: "50px" },
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center"
        }}>
          {/*================== first box====================== */}


          <Box sx={{paddingTop:{xl:"0px ",xs:"20px"}}}>
            <Typography>
              <img src="/public/Images/topfooter/footer-logo.png" alt="logo" />
              {/* Updated image source path */}
            </Typography>
          </Box>

          {/* ====================second box=============== */}
          <Box sx={{
            display: { xl: 'flex', md: "flex", xs: "block" }, justifyContent: 'center'
          }}>
            <Box sx={{
              marginTop: "40px", height: "8rem",
              display: { xl: 'flex', md: "flex", xs: "block" }, justifyContent: "center", alignItems: "center",
              borderTop: "1px solid #e5eef7", borderBottom: "1px solid #e5eef7", textAlign: "center"
            }}
            >
              <Box sx={{ borderRight: '1px solid #e5eef7', height: '70px', width: "25rem" }} >
                <Typography variant="h2" style={{ fontSize: '20px', fontFamily: "poppins", fontWeight: "600" }}>Our Address</Typography >
                <Typography style={{ fontFamily: "poppins", fontSize: "14px", fontwidth: "400", color: '#8d9297' }}>Evanto HQ 24 Fifth st., Los Angeles, USA</Typography>
              </Box>
              <Box sx={{ borderRight: "1px solid #e5eef7", height: '70px', width: "25rem" }}>
                <Typography variant="h5" style={{ fontSize: '20px', fontFamily: "poppins", fontWeight: "600" }}>Talk To Expert</Typography>
                <Typography style={{ fontFamily: "poppins", fontSize: "14px", fontwidth: "400", color: '#8d9297' }}>+1234 567 8910 or +1234 567 8911</Typography>
              </Box>
              <Box sx={{
                // padding: '20px',
                height: '70px',
                width: "25rem"
              }}>
                <Typography variant="h5" style={{ fontSize: '20px', fontFamily: "poppins", fontWeight: "600" }}>Email Us</Typography>
                <Typography style={{ fontFamily: "poppins", fontSize: "14px", fontwidth: "400", color: '#8d9297' }}>example@yourdomain.com</Typography>
              </Box>
            </Box>
          </Box>
          {/*========================= third box========== */}

          <Box
            sx={{
              display: "flex",
              marginTop: { xl: "40px", xs: "100px" }
            }}
          >
            <Box sx={{
              borderRadius: "100px", height: "40px",
              width: { xl: "30rem", xs: "22rem" }, border: "1px solid black", display: "flex", backgroundColor: "red", 
              overflow: "hidden"
            }}>

              <Box sx={{ display: "flex", alignItems: "center", paddingLeft: "10px", backgroundColor: "white" }}><MailOutlineIcon style={{ color: "#8d9297" }} />
                <input type="text" placeholder="Your Email Address" style={{ backgroundColor: "white", height: "40px", width:{xl:"22rem",xs:"5rem"}, border: "none", color: "#8d9297", '&:hover': { border: "none" } }} />
              </Box>
              <Box sx={{ backgroundColor: "red", display: "flex", alignItems: "center" }}><Button sx={{
                height: "40px",
                width: { xl: "6rem", xs: "3rem" },
                backgroundColor: "red",
                // borderTopRightRadius: "100px",
                // borderBottomRightRadius: "100px",
                '&:hover': { backgroundColor: "black" }
              }}>
                <Typography style={{
                  color: "white",
                  fontFamily: "poppins",
                  fontSize: "14px",
                  fontWeight: '600', display: "flex", alignItems: "center"
                }}>submit <ArrowForwardIcon style={{ color: "white" }} /></Typography>
              </Button>
              </Box>



            </Box>





          </Box>
        </Box>
      </Box>
    </>
  );
};

export default FirstBottom;
